<?php
session_start();
include '../database_config/config.php';

if($_SERVER['REQUEST_METHOD'] =='POST')
{
    $email = $_POST['email'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
         
    $checkEmailQuery = "SELECT * FROM customer "
                     . "WHERE email = '$email' ";

    $emailCheckedResult = $conn->query($checkEmailQuery);

    $isValid = FALSE;
    
    if ($emailCheckedResult-> num_rows == 1) 
    {
        $isValid = TRUE;
    }
    
    if($isValid==TRUE)
    {
        //checking email from database
    $updateSQL = "UPDATE customer ".
                 "SET password = '$confirm_password' ".
                 "WHERE email = '$email' ";

        if($conn->query($updateSQL) === TRUE)
        {
            echo "<script>alert('Password has been successfully updated $email');</script>";
            echo "<script>window.location.href = '../php/login.php';</script>";
        }
        else
        {
            echo "<script>alert('Something went wrong with your new password and email');</script>";
            echo "<script>window.location.href = '../php/reset_password.php';</script>";
        }
    }
    else
    {
        echo "<script>alert('Your email does not exit!');</script>";
        echo "<script>window.location.href = '../php/change_password.php';</script>";
    }
    
}