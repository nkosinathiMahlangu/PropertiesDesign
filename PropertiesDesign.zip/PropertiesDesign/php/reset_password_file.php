<?php
    include '../database_config/config.php';
    
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;
    
    require '../phpmailer/src/Exception.php';
    require '../phpmailer/src/PHPMailer.php';
    require '../phpmailer/src/SMTP.php';
    
    if($_SERVER['REQUEST_METHOD'] =='POST')
    {
        $email = $_POST['email'];
         
        $checkEmailQuery = "SELECT * FROM customer "
                         . "WHERE email = '$email' ";
        
        $emailCheckedResult = $conn->query($checkEmailQuery);
        
        if ($emailCheckedResult-> num_rows == 1) 
        {   
            $mail = new PHPMailer(true);
            
            try
            {
                //Server settings
                
                // Set mailer to use SMTP
                $mail->isSMTP(); 
                
                // Specify main and backup SMTP servers
                $mail->Host = 'smtp.gmail.com';
                
                // Enable SMTP authentication
                $mail->SMTPAuth = true;        
                
                // SMTP username
                $mail->Username = 'bryannevhutalu7@gmail.com'; 
                
                // SMTP password
                $mail->Password = 'giczlilkdytwrkuc';    
                
                // Enable TLS encryption, `ssl` also accepted
                $mail->SMTPSecure = 'ssl';    
                
                // TCP port to connect to
                $mail->Port = 465;                 

                //Recipients
                $mail->setFrom('bryannevhutalu7@gmail.com', 'Reset Password');
                
                // Add a recipient
                $mail->addAddress($email);  
                
                // Optional: Add reply-to address
                $mail->addReplyTo($email, 'Information');  

                // Content
                $mail->isHTML(true);  
                $page = 'http://localhost/PropertiesDesign/php/change_password.php"';
                // Set email format to HTML
                $mail->Subject = 'Reset Password';
                $mail->Body ="<b>Click the link below to reset you password</b><br>"
                                   ."$page <br>to update you password.<br>"
                                . "<b>Thank you</b>";
                $mail->AltBody = '';

                $mail->send();
            echo "<script>alert('Email have been sent to reset your password');</script>";

            } catch (Exception $e) {
                echo "<script>alert('Email is not sent. Mailer Error: {$mail->ErrorInfo} ');</script>";
            }
        } 
        else
        {
            echo "<script>alert('Your email does not exits');</script>";
        }
        
    }

