<footer class="bg-dark py-5 mt-5">
        <div class="container text-light text-center">
            <p></p>
            <small class="text-white-50">Copyright &copy;2024 Nova Associates. All rights reserved</small>
        </div>
</footer>