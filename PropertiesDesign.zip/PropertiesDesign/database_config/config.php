<?php
    $dbURL ="localhost";
    $userName = "root";
    $password = "";
    $database = "novaassociates";
    
    //database connection
    $conn = mysqli_connect($dbURL, $userName, $password, $database) or die("Unable to connect to database");
?>

