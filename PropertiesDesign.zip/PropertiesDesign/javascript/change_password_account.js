/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function change_password()
{
    let valid = true;
    
    const new_password = document.getElementById("new_password").value.trim();
    const confirm_password = document.getElementById("confirm_password").value.trim();

    if(confirm_password!=new_password)
    {
        alert("Invalid confirmation passwords");
        isValid = false;
    }
    
    //checking the password requirements
    if (!new_password.match(/^(?=.*[A-Z])(?=.*\d)(?=.*[@!*&])[A-Za-z\d@!*&]{8,}$/) || !confirm_password.match(/^(?=.*[A-Z])(?=.*\d)(?=.*[@!*&])[A-Za-z\d@!*&]{8,}$/)) 
    {
        alert("Password must be at least 8 characters long and contain at least one capital letter, one number, and one symbol (@, !, *, &)");
        isValid = false;
    }
    return isValid; 

}

