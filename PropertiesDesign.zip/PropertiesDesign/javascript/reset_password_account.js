function reset_password()
{
    let isValid = true;
    
    //getting data from the form using id
    const email = document.getElementById("email").value.trim();
    
    //checking the email requirement
    if (!email.match(/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/)) 
    {
        alert("Please fill in the valid email address");
        isValid = false;
    }
 
    return isValid;
}



